package day05;

public class Array04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str[] = {"사과","바나나","복숭아","딸기","포도"};
		
		
		try {
		for(String k:str) {
			System.out.println(k);
			}
		}catch(ArrayIndexOutOfBoundsException a) {
			a.printStackTrace();
		}

	}

}
