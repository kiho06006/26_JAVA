package day05;

import java.util.Scanner;

public class Array01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1차원 배열 선언
		
		int intArray [];
		//배열 생성
		intArray = new int[5];
		//초기화 
		int intMax = 0; //가장 큰수 저장
		int sum = 0;
		Scanner scan = new Scanner(System.in);
		// 양수 5개 입력 받아 배열에 저장 하고, 그 중 가장 큰수 출력하기
//		System.out.println(" 양수 5개를 입력하세요 ");
//		for(int i=0; i<intArray.length; i++) {
//			intArray[i] = scan.nextInt();
//			if(intArray[i] > intMax)
//				intMax = intArray[i];	//최대값 변경
//		}
		
		//합계 구하고 평균 구하기
		System.out.println(" 양수 5개를 입력하세요 ");
		for(int i=0; i<intArray.length; i++) 
			intArray[i] = scan.nextInt();
		for(int i =0; i<intArray.length; i++)
			sum += intArray[i];//최대값 변경
		
		System.out.print("평균은 " + (double)sum/intArray.length + " 입니다.");
		

	}

}
