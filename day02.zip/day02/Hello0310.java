package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//print계열 매소드를 이용해 자바로 하고 싶은 것 작성해서 출력하기.
		System.out.println("이번 대회에서 1번문제는 자바로 풀어보기");
		System.out.println("작년대회 1번문제 풀어보기");
	}

}
