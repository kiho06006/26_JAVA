package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1, 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 20;
		height = 158.9;
		weight = 45.2;
		
		//3. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name = "김수민";
		// name = "김수민";
		String s = new String("홍길동");
		
		String add = new String("대전 동구 용운동");
		DataTypeTest dtt = new DataTypeTest();
		
		// 3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이 : "+age);
		System.out.println("키 : "+height);
		System.out.println("몸무게 : "+weight);
		System.out.println("이름 : "+name);
		System.out.println("주소 : "+add);
		

	}

}
